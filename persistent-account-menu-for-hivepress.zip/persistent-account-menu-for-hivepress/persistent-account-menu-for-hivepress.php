<?php
/**
 * Plugin Name: Persistent Account Menu for HivePress
 * Description: Keeps HivePress account menu items visible even when they are empty, and replaces each empty page with a helpful notice, icon and button.
 * Version: 1.1.0
 * Author: Chris B
 * Author URI: https://community.hivepress.io/u/chrisb
 * Text Domain: persistent-account-menu-for-hivepress
 * Requires PHP: 7.4
 * Requires Plugins: hivepress
 *
 * @package PersistentAccountMenu
 */

namespace PersistentAccountMenu;

use HivePress\Helpers as hp;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Gets the managed menu items.
 *
 * Routes, orders, display conditions, empty-page redirects and page
 * block names are source-verified against HivePress 1.7.26,
 * Favorites 1.2.2, Messages 1.4.0, Bookings 1.5.5, Marketplace 1.3.15,
 * Memberships 2.2.0, Requests 1.2.5 and Search Alerts 1.1.3. Items
 * whose route is not registered (extension inactive) are skipped
 * automatically.
 *
 * @return array<string, array<string, mixed>>
 */
function get_items() {
	static $items = null;

	if ( null !== $items ) {
		return $items;
	}

	$items = [
		'listings_edit'      => [
			'route'  => 'listings_edit_page',
			'_order' => 10,
			'notice' => [
				'icon'   => 'f03a',
				'text'   => __( "You haven't added any listings yet. Once you add your first listing, you can return to this page to view, edit and manage it.", 'persistent-account-menu-for-hivepress' ),
				'button' => [
					'label' => __( 'Add listing', 'persistent-account-menu-for-hivepress' ),
					'route' => 'listing_submit_page',
				],
				'blank'  => [ 'listings' ],
			],
		],

		'requests_edit'      => [
			'route'  => 'requests_edit_page',
			'_order' => 10,
			'notice' => [
				'icon'   => 'f0ae',
				'text'   => __( "You haven't posted any requests yet. Once you post a request, you can return to this page to manage it and review offers.", 'persistent-account-menu-for-hivepress' ),
				'button' => [
					'label' => __( 'Post a request', 'persistent-account-menu-for-hivepress' ),
					'route' => 'request_submit_page',
				],
				'blank'  => [ 'requests' ],
			],
		],

		'offers_view'        => [
			'route'  => 'offers_view_page',
			'_order' => 15,
			'notice' => [
				'icon'   => 'f02c',
				'text'   => __( "You haven't made any offers yet. When you make an offer on a request, it will appear here.", 'persistent-account-menu-for-hivepress' ),
				'button' => [
					'label' => __( 'Browse requests', 'persistent-account-menu-for-hivepress' ),
					'route' => 'requests_view_page',
				],
				'blank'  => [ 'offers' ],
			],
		],

		'listings_favorite'  => [
			'route'  => 'listings_favorite_page',
			'_order' => 20,
			'notice' => [
				'icon'   => 'f004',
				'text'   => __( "You haven't added any listings to your favourites yet. Once you click the heart icon on a listing, you can return to this page to find the listing more easily next time.", 'persistent-account-menu-for-hivepress' ),
				'button' => [
					'label' => __( 'Browse listings', 'persistent-account-menu-for-hivepress' ),
					'route' => 'listings_view_page',
				],
				'blank'  => [ 'listings' ],
			],
		],

		'vendor_calendar'    => [
			'route'  => 'vendor_calendar_page',
			'_order' => 25,
			'vendor' => true,
			'notice' => [
				'icon'   => 'f073',
				'text'   => __( 'Your calendar shows the bookings made for your listings. Add a listing to get started.', 'persistent-account-menu-for-hivepress' ),
				'button' => [
					'label' => __( 'Add listing', 'persistent-account-menu-for-hivepress' ),
					'route' => 'listing_submit_page',
				],
				'blank'  => [],
			],
		],

		'search_alerts_view' => [
			'route'  => 'search_alerts_view_page',
			'_order' => 25,
			'notice' => [
				'icon'   => 'f002',
				'text'   => __( "You haven't saved any searches yet. Save a search to be notified when new matching listings are added.", 'persistent-account-menu-for-hivepress' ),
				'button' => [
					'label' => __( 'Browse listings', 'persistent-account-menu-for-hivepress' ),
					'route' => 'listings_view_page',
				],
				'blank'  => [ 'search_alerts' ],
			],
		],

		'bookings_view'      => [
			'route'  => 'bookings_view_page',
			'_order' => 27,
			'notice' => [
				'icon'   => 'f274',
				'text'   => __( "You don't have any bookings yet. When you make or receive a booking, the details will appear here.", 'persistent-account-menu-for-hivepress' ),
				'button' => [
					'label' => __( 'Browse listings', 'persistent-account-menu-for-hivepress' ),
					'route' => 'listings_view_page',
				],
				'blank'  => [ 'bookings' ],
			],
		],

		'messages_thread'    => [
			'route'   => 'messages_thread_page',
			'_order'  => 30,
			'enabled' => __NAMESPACE__ . '\\is_message_storage_enabled',
			'notice'  => [
				'icon'   => 'f086',
				'text'   => __( "You haven't exchanged any messages yet. When you send or receive a message, the conversation will appear here.", 'persistent-account-menu-for-hivepress' ),
				'button' => [
					'label' => __( 'Browse listings', 'persistent-account-menu-for-hivepress' ),
					'route' => 'listings_view_page',
				],
				'blank'  => [ 'messages' ],
			],
		],

		'memberships_view'   => [
			'route'  => 'memberships_view_page',
			'_order' => 35,
			'notice' => [
				'icon'   => 'f2c2',
				'text'   => __( "You don't have a membership yet. Choose a plan to get started.", 'persistent-account-menu-for-hivepress' ),
				'button' => [
					'label' => __( 'View plans', 'persistent-account-menu-for-hivepress' ),
					'route' => 'membership_plans_view_page',
				],
				'blank'  => [ 'memberships' ],
			],
		],

		'orders_edit'        => [
			'route'  => 'orders_edit_page',
			'_order' => 35,
			'vendor' => true,
			'notice' => [
				'icon'  => 'f07a',
				'text'  => __( "You haven't received any orders yet. When a customer places an order with you, it will appear here.", 'persistent-account-menu-for-hivepress' ),
				'blank' => [ 'orders' ],
			],
		],

		'payouts_view'       => [
			'route'  => 'payouts_view_page',
			'_order' => 45,
			'vendor' => true,
			'notice' => [
				'icon'  => 'f0d6',
				'text'  => __( "You don't have any payouts yet. Once you request a payout, its status will appear here.", 'persistent-account-menu-for-hivepress' ),
				'blank' => [ 'payouts' ],
			],
		],
	];

	// Add the WooCommerce items that HivePress core links into the account
	// menu. These mirror the exact item shape core uses, and their pages
	// already render native WooCommerce empty states, so no notice is set.
	if ( function_exists( 'wc_get_endpoint_url' ) && function_exists( 'wc_get_page_permalink' ) && function_exists( 'wc_get_account_menu_items' ) ) {
		$items['orders_view'] = [
			'label'  => hp\get_array_value( wc_get_account_menu_items(), 'orders', __( 'Orders', 'persistent-account-menu-for-hivepress' ) ),
			'url'    => wc_get_endpoint_url( 'orders', '', wc_get_page_permalink( 'myaccount' ) ),
			'_order' => 40,
		];

		if ( class_exists( 'WC_Subscriptions' ) ) {
			$items['subscriptions_view'] = [
				'label'  => hp\get_array_value( wc_get_account_menu_items(), 'subscriptions', __( 'Subscriptions', 'persistent-account-menu-for-hivepress' ) ),
				'url'    => wc_get_endpoint_url( 'subscriptions', '', wc_get_page_permalink( 'myaccount' ) ),
				'_order' => 42,
			];
		}
	}

	/**
	 * Filters the menu items managed by Persistent Account Menu.
	 *
	 * Unset an item here to stop forcing it, or adjust its notice text,
	 * icon codepoint and button.
	 *
	 * @hook hppam/v1/items
	 */
	$items = apply_filters( 'hppam/v1/items', $items );

	return $items;
}

/**
 * Checks if message storage is enabled.
 *
 * The Messages page route redirects away unconditionally when storage is
 * disabled, so the item is only forced when storage is on.
 *
 * @return bool
 */
function is_message_storage_enabled() {
	return (bool) get_option( 'hp_message_enable_storage' );
}

/**
 * Checks if the current user has a published vendor profile.
 *
 * Used to force vendor-only items for vendors regardless of whether they
 * have data yet. Core's `vendor_id` request context is capability-gated,
 * so the vendor profile is queried directly and cached per request.
 *
 * @return bool
 */
function is_vendor() {
	static $is_vendor = null;

	if ( null === $is_vendor ) {
		$is_vendor = is_user_logged_in() && class_exists( '\HivePress\Models\Vendor' ) && \HivePress\Models\Vendor::query()->filter(
			[
				'status__in' => [ 'pending', 'publish' ],
				'user'       => get_current_user_id(),
			]
		)->get_first_id();
	}

	return (bool) $is_vendor;
}

/**
 * Gets the probe flag, optionally setting it.
 *
 * While the flag is set, the menu filter skips adding forced items so the
 * native menu state can be inspected.
 *
 * @param bool|null $set Flag value.
 * @return bool
 */
function is_probing( $set = null ) {
	static $probing = false;

	if ( null !== $set ) {
		$probing = $set;
	}

	return $probing;
}

/**
 * Checks if an item is present in the native account menu.
 *
 * Extensions only add their item when there is data to show, so a missing
 * item means the page is empty. The native menu is built once per request
 * with forcing suppressed. Guarded against third-party route title
 * callables that are unsafe outside their own context.
 *
 * @param string $name Menu item name.
 * @return bool
 */
function is_native_item( $name ) {
	static $native_items = null;

	if ( null === $native_items ) {
		is_probing( true );

		try {
			$native_items = ( new \HivePress\Menus\User_Account() )->get_items();
		} catch ( \Throwable $e ) {
			$native_items = null;
		} finally {
			is_probing( false );
		}

		if ( ! is_array( $native_items ) ) {

			// Fail safe: treat every item as populated.
			$native_items = array_fill_keys( array_keys( get_items() ), true );
		}
	}

	return isset( $native_items[ $name ] );
}

/**
 * Forces the managed items into the account menu.
 *
 * Runs at priority 500, after every stock condition filter (core at 10,
 * Marketplace at 100), so items added natively are left untouched and
 * only the missing ones are forced.
 *
 * @param array<string, mixed> $menu Menu arguments.
 * @return array<string, mixed>
 */
function alter_account_menu( $menu ) {

	// Never force items in the admin area or while probing the native menu.
	if ( is_admin() || is_probing() || ! is_user_logged_in() ) {
		return $menu;
	}

	foreach ( get_items() as $name => $item ) {

		// Skip items added natively.
		if ( isset( $menu['items'][ $name ] ) ) {
			continue;
		}

		// Skip items disabled by their own condition.
		if ( isset( $item['enabled'] ) && ! call_user_func( $item['enabled'] ) ) {
			continue;
		}

		// Skip vendor items for non-vendors.
		if ( hp\get_array_value( $item, 'vendor' ) && ! is_vendor() ) {
			continue;
		}

		if ( isset( $item['route'] ) ) {

			// Skip items whose extension is inactive.
			if ( ! hivepress()->router->get_route( $item['route'] ) ) {
				continue;
			}

			$menu['items'][ $name ] = [
				'route'  => $item['route'],
				'_order' => $item['_order'],
			];
		} elseif ( isset( $item['url'] ) ) {
			$menu['items'][ $name ] = [
				'label'  => $item['label'],
				'url'    => $item['url'],
				'_order' => $item['_order'],
			];
		}
	}

	// Mirror the Marketplace label when both order lists are present.
	if ( isset( $menu['items']['orders_edit'] ) && isset( $menu['items']['orders_view'] ) ) {
		$menu['items']['orders_view']['label'] = esc_html__( 'Placed Orders', 'hivepress-marketplace' );
	}

	return $menu;
}

add_filter( 'hivepress/v1/menus/user_account', __NAMESPACE__ . '\\alter_account_menu', 500 );

/**
 * Neutralises the empty-page bounce on the managed routes.
 *
 * HivePress account pages redirect back to the account page when they have
 * nothing to show (verified in core and in every managed extension list
 * page), which would
 * make the forced menu links unusable. Each managed route's redirect
 * callbacks are wrapped so that, for logged-in users, a redirect
 * targeting the account page is suppressed while every other redirect
 * (authentication, feature gates, verification) passes through untouched.
 *
 * @param array<string, array<string, mixed>> $routes Route arguments.
 * @return array<string, array<string, mixed>>
 */
function alter_routes( $routes ) {
	foreach ( get_items() as $item ) {
		$name = hp\get_array_value( $item, 'route' );

		if ( ! $name || ! isset( $routes[ $name ]['redirect'] ) ) {
			continue;
		}

		$callbacks = $routes[ $name ]['redirect'];

		// Normalise the callbacks the same way core does.
		if ( count( $callbacks ) === 2 && is_object( hp\get_first_array_value( $callbacks ) ) ) {
			$callbacks = [
				[
					'callback' => $callbacks,
					'_order'   => 5,
				],
			];
		}

		$callbacks = array_filter(
			array_map(
				function ( $args ) {
					return hp\get_array_value( $args, 'callback' );
				},
				hp\sort_array( $callbacks )
			)
		);

		$routes[ $name ]['redirect'] = [
			[
				'callback' => function () use ( $callbacks, $item ) {
					return filter_redirect( $callbacks, $item );
				},

				'_order'   => 5,
			],
		];
	}

	return $routes;
}

add_filter( 'hivepress/v1/routes', __NAMESPACE__ . '\\alter_routes', 500 );

/**
 * Runs the original redirect callbacks, suppressing the empty bounce.
 *
 * The bounce is only suppressed for users the item is actually forced
 * for, so gated pages keep their native behaviour for everyone else.
 *
 * @param array<callable>      $callbacks Original redirect callbacks.
 * @param array<string, mixed> $item Item arguments.
 * @return mixed
 */
function filter_redirect( $callbacks, $item ) {
	$account_url = untrailingslashit( (string) hivepress()->router->get_url( 'user_account_page' ) );

	// Check the item conditions.
	$forcible = is_user_logged_in();

	if ( $forcible && isset( $item['enabled'] ) && ! call_user_func( $item['enabled'] ) ) {
		$forcible = false;
	}

	if ( $forcible && hp\get_array_value( $item, 'vendor' ) && ! is_vendor() ) {
		$forcible = false;
	}

	foreach ( $callbacks as $callback ) {
		$redirect = call_user_func( $callback );

		// Falsy results mean no redirect, the same as in core.
		if ( ! $redirect ) {
			continue;
		}

		// Honour boolean redirects (feature gates) and every redirect
		// for users the item is not forced for.
		if ( is_bool( $redirect ) || ! $forcible ) {
			return $redirect;
		}

		// Suppress the empty bounce back to the account page.
		if ( untrailingslashit( (string) $redirect ) === $account_url ) {
			continue;
		}

		return $redirect;
	}

	return false;
}

/**
 * Adds the empty-state notice to the managed account pages.
 *
 * Hooked on the base account page template, which fires for every child
 * template because HivePress applies template filters for the whole class
 * chain. The notice only renders when the extension itself left the item
 * out of the native menu, meaning the page is empty.
 *
 * @param array<string, mixed> $template Template arguments.
 * @return array<string, mixed>
 */
function alter_account_page( $template ) {
	$route = hivepress()->router->get_current_route_name();

	if ( ! $route ) {
		return $template;
	}

	foreach ( get_items() as $name => $item ) {
		if ( hp\get_array_value( $item, 'route' ) !== $route || ! isset( $item['notice'] ) ) {
			continue;
		}

		// Skip populated pages.
		if ( is_native_item( $name ) ) {
			break;
		}

		$blocks = [
			'hppam_empty_notice' => [
				'type'    => 'content',
				'content' => render_notice( $item['notice'] ),
				'_order'  => 5,
			],
		];

		// Blank the page's own output so the default "Nothing found"
		// message is not shown alongside the notice.
		foreach ( hp\get_array_value( $item['notice'], 'blank', [] ) as $block_name ) {
			$blocks[ $block_name ] = [
				'type'    => 'content',
				'content' => '',
			];
		}

		$template = hp\merge_trees(
			$template,
			[
				'blocks' => [
					'page_content' => [
						'blocks' => $blocks,
					],
				],
			]
		);

		break;
	}

	return $template;
}

add_filter( 'hivepress/v1/templates/user_account_page', __NAMESPACE__ . '\\alter_account_page', 200 );

/**
 * Renders the empty-state notice.
 *
 * The icon is rendered from a Font Awesome codepoint via CSS, matching
 * the solid style bundled with HivePress and compatible with self-hosted
 * Font Awesome 5, 6 and 7.
 *
 * @param array<string, mixed> $notice Notice arguments.
 * @return string
 */
function render_notice( $notice ) {
	$output = '<div class="hppam-empty">';

	// Icon.
	$icon = hp\get_array_value( $notice, 'icon' );

	if ( $icon ) {
		$output .= '<span class="hppam-empty__icon" data-icon="&#x' . esc_attr( $icon ) . ';" aria-hidden="true"></span>';
	}

	// Text.
	$output .= '<p class="hppam-empty__text">' . esc_html( hp\get_array_value( $notice, 'text', '' ) ) . '</p>';

	// Button.
	$button = hp\get_array_value( $notice, 'button' );

	if ( $button ) {
		$url = hivepress()->router->get_url( hp\get_array_value( $button, 'route', '' ) );

		if ( $url ) {
			$output .= '<a href="' . esc_url( $url ) . '" class="hppam-empty__button button alt">' . esc_html( hp\get_array_value( $button, 'label', '' ) ) . '</a>';
		}
	}

	$output .= '</div>';

	/**
	 * Filters the rendered empty-state notice.
	 *
	 * @hook hppam/v1/notice_html
	 */
	return apply_filters( 'hppam/v1/notice_html', $output, $notice );
}

/**
 * Enqueues the notice styles on the managed account pages.
 *
 * @return void
 */
function enqueue_styles() {
	if ( ! function_exists( 'hivepress' ) ) {
		return;
	}

	$route = hivepress()->router->get_current_route_name();

	if ( ! $route || ! in_array( $route, array_filter( array_column( get_items(), 'route' ) ), true ) ) {
		return;
	}

	wp_register_style( 'hppam-frontend', false, [], '1.0.0' );
	wp_enqueue_style( 'hppam-frontend' );

	wp_add_inline_style(
		'hppam-frontend',
		'.hppam-empty{display:flex;flex-direction:column;align-items:center;text-align:center;padding:3rem 1rem;gap:1rem}
		.hppam-empty__icon::before{content:attr(data-icon);font-family:"Font Awesome 5 Free","Font Awesome 6 Free","Font Awesome 7 Free";font-weight:900;font-size:2.75rem;line-height:1;opacity:.25}
		.hppam-empty__text{max-width:26rem;margin:0}
		.hppam-empty__button{margin-top:.25rem}'
	);
}

add_action( 'wp_enqueue_scripts', __NAMESPACE__ . '\\enqueue_styles' );
